<?php
require_once dirname(__DIR__) . '/vendor/autoload.php';

use App\AuthService;
use App\ProductController;
use App\UserController;
use App\Response;

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true) ?? [];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$path = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
$resource = $_GET['route'] ?? basename($path);

$authClass = class_exists('App\AuthService') ? 'App\AuthService' : (class_exists('AuthService') ? 'AuthService' : 'App\AuthService');
$userControllerClass = class_exists('App\UserController') ? 'App\UserController' : (class_exists('UserController') ? 'UserController' : 'App\UserController');
$productControllerClass = class_exists('App\ProductController') ? 'App\ProductController' : (class_exists('ProductController') ? 'ProductController' : 'App\ProductController');
$responseClass = class_exists('App\Response') ? 'App\Response' : (class_exists('Response') ? 'Response' : 'App\Response');

$auth = new $authClass();
$userController = new $userControllerClass($auth);
$productController = new $productControllerClass();

function getAuthorizationHeader(): ?string
{
    $headers = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? null;

    if (!$headers) {
        return null;
    }

    if (stripos($headers, 'Bearer ') === 0) {
        return trim(substr($headers, 7));
    }

    return trim($headers);
}

try {
    $isAuthRoute = ($resource === 'login' && $method === 'POST') || ($resource === 'register' && $method === 'POST');

    if ($resource === 'login' && $method === 'POST') {
        $userController->login($input);
        return;
    }

    if ($resource === 'register' && $method === 'POST') {
        $userController->register($input);
        return;
    }

    // Para endpoints protegidos: exigir token válido.
    if (!$isAuthRoute) {
        $auth->validateToken(getAuthorizationHeader());
    }



    switch ($method) {
        case 'GET':
            $productController->get($id ?: null);
            break;
        case 'POST':
            $productController->post($input);
            break;
        case 'PUT':
            $productController->put($id, $input);
            break;
        case 'DELETE':
            $productController->delete($id);
            break;
        default:
            Response::json(['success' => false, 'message' => 'Método no permitido.'], 405);
    }
} catch (Throwable $e) {
    Response::json([
        'success' => false,
        'message' => 'Acceso no autorizado o token inválido.',
        'error' => $e->getMessage()
    ], 401);
}
