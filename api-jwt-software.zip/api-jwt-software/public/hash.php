<?php
$resultado = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['accion'] ?? '') === 'generar') {
        $resultado = password_hash($_POST['password'] ?? '', PASSWORD_BCRYPT);
    }

    if (($_POST['accion'] ?? '') === 'validar') {
        $resultado = password_verify($_POST['password'] ?? '', $_POST['hash'] ?? '')
            ? 'Contraseña válida.'
            : 'Contraseña incorrecta.';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Hash BCRYPT</title>
    <style>
        body{font-family:Arial;background:#eef6ff;padding:40px}
        .card{max-width:800px;margin:auto;background:#fff;padding:25px;border-radius:16px;box-shadow:0 10px 30px #0002}
        input,textarea,button{width:100%;padding:12px;margin:8px 0;border-radius:10px;border:1px solid #ccc}
        button{background:#0d6efd;color:white;font-weight:bold;cursor:pointer}
        textarea{height:110px}
    </style>
</head>
<body>
<div class="card">
    <h1>Interfaz para generar y validar Hash BCRYPT</h1>

    <form method="post">
        <h2>Generar Hash</h2>
        <input type="hidden" name="accion" value="generar">
        <input type="text" name="password" placeholder="Contraseña" required>
        <button>Generar Hash</button>
    </form>

    <form method="post">
        <h2>Validar Hash</h2>
        <input type="hidden" name="accion" value="validar">
        <input type="text" name="password" placeholder="Contraseña" required>
        <textarea name="hash" placeholder="Pega aquí el hash" required></textarea>
        <button>Validar</button>
    </form>

    <?php if ($resultado): ?>
        <h2>Resultado</h2>
        <textarea readonly><?= htmlspecialchars($resultado, ENT_QUOTES, 'UTF-8') ?></textarea>
    <?php endif; ?>
</div>
</body>
</html>
