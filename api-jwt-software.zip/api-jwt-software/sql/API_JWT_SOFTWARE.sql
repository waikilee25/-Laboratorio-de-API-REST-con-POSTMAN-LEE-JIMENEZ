CREATE DATABASE IF NOT EXISTS API_JWT_SOFTWARE CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE api_rest_jwt;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(20) NOT NULL UNIQUE,
    producto VARCHAR(100) NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    cantidad INT NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO usuarios (usuario, password_hash)
VALUES ('admin', '$2y$12$KdCs.rf.ZlRBlNGYZrH1IugqfkYfSLSBq9aC5eE2OVQdz.amoLGiy')
ON DUPLICATE KEY UPDATE usuario = usuario;

INSERT INTO productos (codigo, producto, precio, cantidad) VALUES
('A001', 'Mouse óptico', 10.50, 5),
('A002', 'Teclado USB', 15.75, 8),
('A003', 'Monitor LED', 120.00, 3)
ON DUPLICATE KEY UPDATE codigo = codigo;
