<?php
return [
    'db' => [
        'host'     => 'localhost',
        'database' => 'api_rest_jwt',
        'user'     => 'root',
        'password' => '123456',
        'charset'  => 'utf8mb4'
    ],
    'jwt' => [
        'secret'             => 'Tu_Clave_Secreta_Super_Ultra_Segura_2026',
        'issuer'             => 'http://localhost/api-jwt-software/public',
        'expiration_seconds' => 3600
    ]
];
