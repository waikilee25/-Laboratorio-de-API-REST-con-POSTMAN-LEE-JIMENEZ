<?php
return [
    'db' => [
        'host' => 'localhost',
        'database' => 'api-jwt-software',
        'user' => 'root',
        'password' => '',
        'charset' => 'utf8mb4'
    ],
    'jwt' => [
        'secret' => 'CAMBIA_ESTA_CLAVE_SECRETA',
        'issuer' => 'http://localhost/API-JWT-SOFTWARE/public',
        'expiration_seconds' => 3600
    ]
];
