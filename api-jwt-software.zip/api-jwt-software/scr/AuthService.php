<?php
namespace App;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Exception;
use Throwable;

class AuthService
{
    private string $secret;
    private string $issuer;
    private int $expirationSeconds;

    public function __construct()
    {
        $config = require dirname(__DIR__) . '/config.php';
        $this->secret = $config['jwt']['secret'];
        $this->issuer = $config['jwt']['issuer'];
        $this->expirationSeconds = (int)$config['jwt']['expiration_seconds'];
    }

    // Genera el token JWT del usuario.
    public function generateToken(array $user): string
    {
        $now = time();

        $payload = [
            'iss' => $this->issuer,
            'iat' => $now,
            'exp' => $now + $this->expirationSeconds,
            'data' => [
                'id' => $user['id'],
                'usuario' => $user['usuario']
            ]
        ];

        return JWT::encode($payload, $this->secret, 'HS256');
    }

    // Valida el token recibido por Authorization Bearer.
    public function validateToken(?string $authorizationHeader): array
    {
        if (!$authorizationHeader) {
            throw new Exception('Token no enviado.');
        }

        $authorizationHeader = trim($authorizationHeader);
        if (!preg_match('/^Bearer\s+(.+)$/i', $authorizationHeader, $m)) {
            throw new Exception('Formato de Authorization inválido.');
        }

        $token = trim($m[1]);
        if ($token === '') {
            throw new Exception('Token no enviado.');
        }

        try {
            $decoded = JWT::decode($token, new Key($this->secret, 'HS256'));
            return json_decode(json_encode($decoded), true);
        } catch (Throwable $e) {
            // Mantener contrato: cualquier token inválido responde 401 desde public/index.php
            throw new Exception('Token inválido.');
        }
    }


    // Obtiene el header Authorization en Wamp/Apache.
    public static function getAuthorizationHeader(): ?string
    {
        if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
            return $_SERVER['HTTP_AUTHORIZATION'];
        }

        if (function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            return $headers['Authorization'] ?? $headers['authorization'] ?? null;
        }

        return null;
    }
}
