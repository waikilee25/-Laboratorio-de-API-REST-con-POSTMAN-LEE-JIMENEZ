
<?php
return [
    'db' => [
        'host'     => '127.0.0.1',
        'port'     => '3307',
        'database' => 'api_jwt_software',
        'user'     => 'jwt_app',
        'password' => 'JwtApp_2026!',
        'charset'  => 'utf8mb4'
    ],
    'jwt' => [
        'secret'             => 'Tu_Clave_Secreta_Super_Ultra_Segura_2026',
        'issuer'             => 'http://localhost/api-jwt-software/public',
        'expiration_seconds' => 3600
    ]
];
