<?php
return [
    'db' => [
        'host' => 'localhost',
        'database' => 'api_rest_jwt',
        'user' => 'root',
        'password' => '',
        'charset' => 'utf8mb4'
    ],
    'jwt' => [
        'secret' => 'CAMBIA_ESTA_CLAVE_SECRETA',
        'issuer' => 'http://localhost/Lab_API_REST_JWT_Jorge/public',
        'expiration_seconds' => 3600
    ]
];
