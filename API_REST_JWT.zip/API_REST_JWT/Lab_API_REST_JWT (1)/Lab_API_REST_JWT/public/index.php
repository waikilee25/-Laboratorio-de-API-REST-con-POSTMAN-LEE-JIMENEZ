<?php
require_once dirname(__DIR__) . '/vendor/autoload.php';

use App\AuthService;
use App\ProductController;
use App\UserController;
use App\Response;

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true) ?? [];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$path = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
$resource = $_GET['route'] ?? basename($path);

$auth = new AuthService();
$userController = new UserController($auth);
$productController = new ProductController();

try {
    if ($resource === 'login' && $method === 'POST') {
        $userController->login($input);
    }

    if ($resource === 'register' && $method === 'POST') {
        $userController->register($input);
    }

    $auth->validateToken(AuthService::getAuthorizationHeader());

    switch ($method) {
        case 'GET':
            $productController->get($id ?: null);
            break;
        case 'POST':
            $productController->post($input);
            break;
        case 'PUT':
            $productController->put($id, $input);
            break;
        case 'DELETE':
            $productController->delete($id);
            break;
        default:
            Response::json(['success' => false, 'message' => 'Método no permitido.'], 405);
    }
} catch (Throwable $e) {
    Response::json([
        'success' => false,
        'message' => 'Acceso no autorizado o token inválido.',
        'error' => $e->getMessage()
    ], 401);
}
