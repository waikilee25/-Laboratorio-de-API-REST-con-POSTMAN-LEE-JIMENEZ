<?php
namespace App;

class UserController
{
    private AuthService $auth;

    public function __construct(AuthService $auth)
    {
        $this->auth = $auth;
    }

    // Realiza login y devuelve un token JWT.
    public function login(array $input): void
    {
        $usuario = trim($input['usuario'] ?? '');
        $password = $input['password'] ?? '';

        if ($usuario === '' || $password === '') {
            Response::json(['success' => false, 'message' => 'Usuario y contraseña son obligatorios.'], 400);
        }

        $users = DB::query(
            'SELECT id, usuario, password_hash FROM usuarios WHERE usuario = :usuario',
            [':usuario' => $usuario]
        );

        if (!$users || !password_verify($password, $users[0]['password_hash'])) {
            Response::json(['success' => false, 'message' => 'Credenciales incorrectas.'], 401);
        }

        Response::json([
            'success' => true,
            'message' => 'Login correcto.',
            'token' => $this->auth->generateToken($users[0]),
            'type' => 'Bearer'
        ]);
    }

    // Registra usuarios usando password_hash con BCRYPT.
    public function register(array $input): void
    {
        $usuario = trim($input['usuario'] ?? '');
        $password = $input['password'] ?? '';

        if ($usuario === '' || strlen($password) < 6) {
            Response::json(['success' => false, 'message' => 'Usuario obligatorio y contraseña mínima de 6 caracteres.'], 400);
        }

        DB::execute(
            'INSERT INTO usuarios (usuario, password_hash) VALUES (:usuario, :hash)',
            [':usuario' => $usuario, ':hash' => password_hash($password, PASSWORD_BCRYPT)]
        );

        Response::json(['success' => true, 'message' => 'Usuario creado correctamente.'], 201);
    }
}
