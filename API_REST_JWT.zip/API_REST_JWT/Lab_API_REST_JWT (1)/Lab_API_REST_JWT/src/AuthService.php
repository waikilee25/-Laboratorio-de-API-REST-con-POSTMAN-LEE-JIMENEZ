<?php
namespace App;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Exception;

class AuthService
{
    private string $secret;
    private string $issuer;
    private int $expirationSeconds;

    public function __construct()
    {
        $config = require dirname(__DIR__) . '/config.php';
        $this->secret = $config['jwt']['secret'];
        $this->issuer = $config['jwt']['issuer'];
        $this->expirationSeconds = (int)$config['jwt']['expiration_seconds'];
    }

    // Genera el token JWT del usuario.
    public function generateToken(array $user): string
    {
        $now = time();

        $payload = [
            'iss' => $this->issuer,
            'iat' => $now,
            'exp' => $now + $this->expirationSeconds,
            'data' => [
                'id' => $user['id'],
                'usuario' => $user['usuario']
            ]
        ];

        return JWT::encode($payload, $this->secret, 'HS256');
    }

    // Valida el token recibido por Authorization Bearer.
    public function validateToken(?string $authorizationHeader): array
    {
        if (!$authorizationHeader || !str_starts_with($authorizationHeader, 'Bearer ')) {
            throw new Exception('Token no enviado.');
        }

        $token = trim(str_replace('Bearer ', '', $authorizationHeader));
        $decoded = JWT::decode($token, new Key($this->secret, 'HS256'));

        return json_decode(json_encode($decoded), true);
    }

    // Obtiene el header Authorization en Wamp/Apache.
    public static function getAuthorizationHeader(): ?string
    {
        if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
            return $_SERVER['HTTP_AUTHORIZATION'];
        }

        if (function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            return $headers['Authorization'] ?? $headers['authorization'] ?? null;
        }

        return null;
    }
}
