<?php
namespace App;

use PDO;

class DB
{
    private static ?PDO $connection = null;

    // Crea y reutiliza la conexión PDO.
    public static function connect(): PDO
    {
        if (self::$connection === null) {
            $config = require dirname(__DIR__) . '/config.php';
            $db = $config['db'];
            $port = $db['port'] ?? '3306';
$dsn = "mysql:host={$db['host']};port={$port};dbname={$db['database']};charset={$db['charset']}";

            self::$connection = new PDO($dsn, $db['user'], $db['password'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]);
        }
        return self::$connection;
    }

    // Ejecuta consultas SELECT con parámetros.
    public static function query(string $sql, array $params = []): array
    {
        $stmt = self::connect()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    // Ejecuta INSERT, UPDATE o DELETE con parámetros.
    public static function execute(string $sql, array $params = []): bool
    {
        $stmt = self::connect()->prepare($sql);
        return $stmt->execute($params);
    }

    // Devuelve el último ID insertado.
    public static function lastInsertId(): string
    {
        return self::connect()->lastInsertId();
    }
}
