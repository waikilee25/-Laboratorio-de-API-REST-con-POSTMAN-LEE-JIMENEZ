<?php
namespace App;

class ProductController
{
    // Consulta todos los productos o uno por ID.
    public function get(?int $id = null): void
    {
        if ($id) {
            $rows = DB::query('SELECT * FROM productos WHERE id = :id', [':id' => $id]);
            if (!$rows) {
                Response::json(['success' => false, 'message' => 'Producto no encontrado.'], 404);
            }
            Response::json(['success' => true, 'data' => $rows[0]]);
        }

        Response::json(['success' => true, 'data' => DB::query('SELECT * FROM productos ORDER BY id DESC')]);
    }

    // Crea un nuevo producto.
    public function post(array $input): void
    {
        $errors = $this->validate($input);
        if ($errors) {
            Response::json(['success' => false, 'message' => 'Datos inválidos.', 'errors' => $errors], 400);
        }

        DB::execute(
            'INSERT INTO productos (codigo, producto, precio, cantidad) VALUES (:codigo, :producto, :precio, :cantidad)',
            [
                ':codigo' => $this->clean($input['codigo']),
                ':producto' => $this->clean($input['producto']),
                ':precio' => (float)$input['precio'],
                ':cantidad' => (int)$input['cantidad']
            ]
        );

        Response::json(['success' => true, 'message' => 'Producto creado correctamente.', 'id' => DB::lastInsertId()], 201);
    }

    // Actualiza un producto existente.
    public function put(int $id, array $input): void
    {
        $errors = $this->validate($input);
        if ($id <= 0) {
            $errors['id'] = 'ID inválido.';
        }

        if ($errors) {
            Response::json(['success' => false, 'message' => 'Datos inválidos.', 'errors' => $errors], 400);
        }

        DB::execute(
            'UPDATE productos SET codigo=:codigo, producto=:producto, precio=:precio, cantidad=:cantidad WHERE id=:id',
            [
                ':id' => $id,
                ':codigo' => $this->clean($input['codigo']),
                ':producto' => $this->clean($input['producto']),
                ':precio' => (float)$input['precio'],
                ':cantidad' => (int)$input['cantidad']
            ]
        );

        Response::json(['success' => true, 'message' => 'Producto actualizado correctamente.']);
    }

    // Elimina un producto.
    public function delete(int $id): void
    {
        if ($id <= 0) {
            Response::json(['success' => false, 'message' => 'ID inválido.'], 400);
        }

        DB::execute('DELETE FROM productos WHERE id = :id', [':id' => $id]);
        Response::json(['success' => true, 'message' => 'Producto eliminado correctamente.']);
    }

    // Valida los datos de entrada.
    private function validate(array $input): array
    {
        $errors = [];

        if (empty($input['codigo'])) $errors['codigo'] = 'El código es obligatorio.';
        if (empty($input['producto'])) $errors['producto'] = 'El producto es obligatorio.';
        if (!isset($input['precio']) || (float)$input['precio'] <= 0) $errors['precio'] = 'El precio debe ser mayor a cero.';
        if (!isset($input['cantidad']) || (int)$input['cantidad'] < 0) $errors['cantidad'] = 'La cantidad no puede ser negativa.';

        return $errors;
    }

    // Sanitiza texto.
    private function clean(string $value): string
    {
        return htmlspecialchars(strip_tags(trim($value)), ENT_QUOTES, 'UTF-8');
    }
}
